export const siteMeta = {
  clubName: 'SASE at [University Name]',
  title: 'Society of Asian Scientists and Engineers',
  description:
    'Official website boilerplate for a university chapter of the Society of Asian Scientists and Engineers.',
  tagline: 'Empowering Asian heritage scientific and engineering leaders.',
  logoText: 'SASE',
};

export const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Executive Board', href: '/executive-board' },
  { label: '3 Pillars', href: '/pillars' },
  { label: 'Programs', href: '/programs' },
  { label: 'Conferences', href: '/conferences' },
  { label: 'Events', href: '/events' },
  { label: 'Sponsorship', href: '/sponsorship' },
  { label: 'Alumni', href: '/alumni' },
];

export const homepageHighlights = [
  {
    title: 'Leadership',
    description: 'Introduce your executive board, roles, and the people behind your chapter.',
    href: '/executive-board',
  },
  {
    title: 'Community',
    description: 'Explain your mission, pillars, programs, and signature chapter experiences.',
    href: '/pillars',
  },
  {
    title: 'Opportunities',
    description: 'Share conferences, events, sponsorship info, and ways alumni can reconnect.',
    href: '/events',
  },
];

export const executiveBoard = [
  {
    name: 'Board Member 1',
    role: 'President',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 2',
    role: 'Vice President',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 3',
    role: 'Treasurer',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 4',
    role: 'Secretary',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 5',
    role: 'Events Chair',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 6',
    role: 'Professional Development Chair',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 7',
    role: 'Outreach Chair',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
  {
    name: 'Board Member 8',
    role: 'Public Relations Chair',
    major: 'Major / Year',
    bio: 'Short placeholder biography. Replace with a brief introduction, interests, and leadership focus.',
  },
];

export const pillars = [
  {
    title: 'Pillar 1',
    subtitle: 'Replace with the first SASE pillar',
    description:
      'Use this area to describe what this pillar means for your chapter, what goals it supports, and how members experience it.',
    bulletPoints: ['Placeholder point one', 'Placeholder point two', 'Placeholder point three'],
  },
  {
    title: 'Pillar 2',
    subtitle: 'Replace with the second SASE pillar',
    description:
      'Use this area to describe what this pillar means for your chapter, what goals it supports, and how members experience it.',
    bulletPoints: ['Placeholder point one', 'Placeholder point two', 'Placeholder point three'],
  },
  {
    title: 'Pillar 3',
    subtitle: 'Replace with the third SASE pillar',
    description:
      'Use this area to describe what this pillar means for your chapter, what goals it supports, and how members experience it.',
    bulletPoints: ['Placeholder point one', 'Placeholder point two', 'Placeholder point three'],
  },
];

export const programs = [
  {
    title: 'Program 1',
    audience: 'Who it is for',
    summary:
      'Describe the purpose of this program, the experience it provides, and how members benefit from joining it.',
    features: ['Feature or benefit', 'Meeting format', 'Expected outcomes'],
  },
  {
    title: 'Program 2',
    audience: 'Who it is for',
    summary:
      'Describe the purpose of this program, the experience it provides, and how members benefit from joining it.',
    features: ['Feature or benefit', 'Meeting format', 'Expected outcomes'],
  },
];

export const conferences = [
  {
    title: 'Conference 1',
    season: 'Season / Term',
    description:
      'Summarize what this conference is, why your chapter attends, and what members can expect from participating.',
    details: ['Registration timeline', 'Travel notes', 'What members gain'],
  },
  {
    title: 'Conference 2',
    season: 'Season / Term',
    description:
      'Summarize what this conference is, why your chapter attends, and what members can expect from participating.',
    details: ['Registration timeline', 'Travel notes', 'What members gain'],
  },
];

export const upcomingEvents = [
  {
    title: 'Upcoming Event Placeholder',
    date: 'Month Day, Year',
    location: 'Location / Room / Online',
    summary: 'Add a short overview of the event purpose, audience, and what attendees should know.',
  },
  {
    title: 'Upcoming Event Placeholder',
    date: 'Month Day, Year',
    location: 'Location / Room / Online',
    summary: 'Add a short overview of the event purpose, audience, and what attendees should know.',
  },
];

export const pastEvents = [
  {
    title: 'Past Event Placeholder',
    date: 'Month Day, Year',
    location: 'Location / Room / Online',
    summary: 'Use this to recap the event, impact, turnout, or memorable takeaways.',
  },
  {
    title: 'Past Event Placeholder',
    date: 'Month Day, Year',
    location: 'Location / Room / Online',
    summary: 'Use this to recap the event, impact, turnout, or memorable takeaways.',
  },
];

export const sponsorshipSections = [
  {
    title: 'Why Partner With Us',
    description:
      'Introduce your chapter audience, member demographics, campus reach, and why sponsorship creates value for companies.',
  },
  {
    title: 'What Sponsors Can Support',
    description:
      'List the kinds of initiatives sponsors can help fund, such as conferences, events, mentorship, or career development.',
  },
  {
    title: 'How to Get In Touch',
    description:
      'Add contact details, response expectations, and a link or file reference for your sponsorship package.',
  },
];

export const alumniSections = [
  {
    title: 'Reconnect With the Chapter',
    description:
      'Invite alumni to stay involved through mentoring, speaking, networking, or chapter support.',
  },
  {
    title: 'Ways to Engage',
    description:
      'Use this section to explain alumni panels, mentorship, donations, resume support, or event participation.',
  },
  {
    title: 'Stay Updated',
    description:
      'Add any newsletter, LinkedIn, email list, or form information for alumni to stay connected.',
  },
];
